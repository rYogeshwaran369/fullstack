package com.backend.yogesh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YogeshApplication {

	public static void main(String[] args) {
		SpringApplication.run(YogeshApplication.class, args);
	}
}
